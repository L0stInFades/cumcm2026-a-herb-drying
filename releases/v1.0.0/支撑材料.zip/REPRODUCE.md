# 复现说明（run `20260912-153103-eb858bf`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `fe6f6aa43bbeda58e6102875ebb816b2ea34c453`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| convergence | completed | 44.0 | `8744f13277a4460d` | `ta-01M2A8TW9Z11CY607A8VQPPDCR` |
| derived | completed | 0.0 | `9e38afc4ea7d8ea0` | `ta-01M2A9E2C41TVZKWKA32KRP0TR` |
| extension | completed | 14.0 | `517768db57ea1eb8` | `ta-01M2A8J3QSFS9Z3MRDGMNW2DQR` |
| figures | completed | 24.0 | `f4528c37f90aa6f8` | `ta-01M2A8RGSP1WBAH5DPGTVQ68RR` |
| fmt | completed | 0.0 | `bbcf15b835d105f0` | `ta-01M2AACCZ8P0NPQZ9WKGX3ZP7R` |
| ingest | completed | 0.0 | `8a1cfe99b7db064f` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| lint | completed | 21.0 | `ed8b1eef0b56addc` | `ta-01M2AAE4SRN4VZSGSHJ53E48QR` |
| package | completed* | 0.0 | `` | `ta-01M2AB3VAFW49FHCQX634ZB2VR` |
| paper | completed | 64.0 | `ee327b8211625e25` | `ta-01M2AB3VAFW49FHCQX634ZB2VR` |
| q1 | completed | 1.0 | `2719c054535896a1` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| q2 | completed | 8.0 | `80eca2cfc51b5aac` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| q3 | completed | 11.0 | `184ae69c83a31e9e` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| q4 | completed | 86.0 | `d796b82cf9f047bd` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| qa | completed | 6.0 | `effb2641de0dcfd4` | `ta-01M2AB3VAFW49FHCQX634ZB2VR` |
| release | completed | 0.0 | `f55aad54861a1498` | `ta-01M2AAQNS12CXFBJ01WGEB2T9R` |
| results | completed | 14.0 | `410f44c2a0adf5ff` | `ta-01M2A8RGSP1WBAH5DPGTVQ68RR` |
| sensitivity | completed | 64.0 | `665ab84af17d7c2c` | `ta-01M2A8J3QSFS9Z3MRDGMNW2DQR` |
| tables | completed | 0.0 | `e7715c4765993e8e` | `ta-01M2A9G2B0F8G3GF648WHCBMJR` |
| test | completed | 18.0 | `000dc94c2f1fdd39` | `ta-01M2AAE4SRN4VZSGSHJ53E48QR` |
| validate | completed | 0.0 | `7386c362f110e74d` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| verification | completed | 43.0 | `7ff7dd0f031c0fc0` | `ta-01M2A8J3QSFS9Z3MRDGMNW2DQR` |

## 复现命令

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run q1,q2,q3,q4 --size medium
python3 tools/cli.py run convergence,verification,sensitivity,extension,derived --size medium
python3 tools/cli.py run results,figures,tables
python3 tools/cli.py run lint,test,paper,qa,package,release
python3 tools/cli.py release --version v1.0.0
```

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
