# 复现说明（run `20260912-104036-184d092`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `133907f7e0094708390d1c38a4364b428ecbe78f`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| convergence | completed | 39.0 | `e7c97c4bb47b9df8` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| derived | completed | 0.0 | `ff7b3a16d642817b` | `ta-01M2A277JDS82NMTFJ6TBSXQSR` |
| extension | completed | 13.0 | `0fb634d889173f6d` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| figures | completed | 22.0 | `9e12255aa52a2435` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| ingest | completed | 1.0 | `8a1cfe99b7db064f` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| lint | completed | 21.0 | `ed8b1eef0b56addc` | `ta-01M2A360Y6N5PABC90C9CDJ8VR` |
| package | running | 0.0 | `` | `ta-01M2A4BYFCFDM514R6NFQC2KJR` |
| paper | completed | 61.0 | `aa51a57211e6658a` | `ta-01M2A4BYFCFDM514R6NFQC2KJR` |
| q1 | completed | 2.0 | `ade62f528fb34278` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| q2 | completed | 9.0 | `96d113bd82d98ce1` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| q3 | completed | 13.0 | `9883d8006f55c5fd` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| q4 | completed | 97.0 | `af58b9c29cfa5e1c` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| qa | completed | 5.0 | `c1e2f70f1e771a9c` | `ta-01M2A4BYFCFDM514R6NFQC2KJR` |
| results | completed | 11.0 | `a16209cb604ae058` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| sensitivity | completed | 52.0 | `433ff43536256d87` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| tables | completed | 1.0 | `4e22ebca15e0f9f4` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| test | completed | 17.0 | `89c56adc82b86340` | `ta-01M2A360Y6N5PABC90C9CDJ8VR` |
| validate | completed | 0.0 | `7386c362f110e74d` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |
| verification | completed | 36.0 | `746753d0aa5cc97c` | `ta-01M29QT4HEQM2K9MNQ6Q15KY1R` |

## 复现命令

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run <科学阶段...> --size medium
python3 tools/cli.py run lint,test,paper,qa,package,release
python3 tools/cli.py release --version <tag>
```

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
