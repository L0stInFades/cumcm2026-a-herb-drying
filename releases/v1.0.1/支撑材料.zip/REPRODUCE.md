# 复现说明（run `20260912-153103-eb858bf`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `47ec9ff3f166a857f30b1749bdc644e110b898a8`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| convergence | completed | 44.0 | `8744f13277a4460d` | `ta-01M2A8TW9Z11CY607A8VQPPDCR` |
| derived | completed | 0.0 | `9e38afc4ea7d8ea0` | `ta-01M2A9E2C41TVZKWKA32KRP0TR` |
| extension | completed | 14.0 | `517768db57ea1eb8` | `ta-01M2A8J3QSFS9Z3MRDGMNW2DQR` |
| figures | completed | 24.0 | `f4528c37f90aa6f8` | `ta-01M2A8RGSP1WBAH5DPGTVQ68RR` |
| fmt | completed | 0.0 | `fa9c2aec2c2a588c` | `ta-01M2AXFFVY3XTEDXTJXGYV3JWR` |
| ingest | completed | 0.0 | `8a1cfe99b7db064f` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| lint | completed | 18.0 | `cd5e1ca31d0d8559` | `ta-01M2AXH20GPWD0N3M9H1878HAR` |
| package | completed* | 0.0 | `` | `ta-01M2AXJY60VDFX22CKEE2T4PVR` |
| paper | completed | 69.0 | `5103f9b8d7650fbc` | `ta-01M2AXJY60VDFX22CKEE2T4PVR` |
| q1 | completed | 1.0 | `2719c054535896a1` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| q2 | completed | 8.0 | `80eca2cfc51b5aac` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| q3 | completed | 11.0 | `184ae69c83a31e9e` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| q4 | completed | 86.0 | `d796b82cf9f047bd` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| qa | completed | 7.0 | `7a6ecb3e3190375e` | `ta-01M2AXJY60VDFX22CKEE2T4PVR` |
| release | completed | 0.0 | `f976f1c58cd21a56` | `ta-01M2AB3VAFW49FHCQX634ZB2VR` |
| results | completed | 14.0 | `410f44c2a0adf5ff` | `ta-01M2A8RGSP1WBAH5DPGTVQ68RR` |
| sensitivity | completed | 64.0 | `665ab84af17d7c2c` | `ta-01M2A8J3QSFS9Z3MRDGMNW2DQR` |
| tables | completed | 0.0 | `e7715c4765993e8e` | `ta-01M2A9G2B0F8G3GF648WHCBMJR` |
| test | completed | 16.0 | `f03582d4efb4a848` | `ta-01M2AXH20GPWD0N3M9H1878HAR` |
| validate | completed | 0.0 | `7386c362f110e74d` | `ta-01M2A8E05JHGYJKNCY508JMC0R` |
| verification | completed | 43.0 | `7ff7dd0f031c0fc0` | `ta-01M2A8J3QSFS9Z3MRDGMNW2DQR` |

## 复现命令

### A. 云端（本文使用的方式，需要 Modal 账号）

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run convergence --size medium
python3 tools/cli.py run derived --size medium
python3 tools/cli.py run extension --size medium
python3 tools/cli.py run figures --size medium
python3 tools/cli.py run lint --size medium
python3 tools/cli.py run package --size medium
python3 tools/cli.py run paper --size medium
python3 tools/cli.py run q1 --size medium
python3 tools/cli.py run q2 --size medium
python3 tools/cli.py run q3 --size medium
python3 tools/cli.py run q4 --size medium
python3 tools/cli.py run qa --size medium
python3 tools/cli.py run release --size medium
python3 tools/cli.py run results --size medium
python3 tools/cli.py run sensitivity --size medium
python3 tools/cli.py run tables --size medium
python3 tools/cli.py run test --size medium
python3 tools/cli.py run verification --size medium
python3 tools/cli.py release --version <tag>
```

各阶段的确切参数（线程数、逐级时限）见每个阶段目录下 `manifest.json` 的 `params` 字段，
以及 `docs/RUNBOOK.md` 第 7 节。

### B. 本地（不需要任何云端账号）

```bash
pip install pandas numpy openpyxl pyarrow networkx matplotlib ortools highspy
python3 tools/run_local.py --quick        # 数分钟，得到 result1-4.xlsx、图与表
python3 tools/run_local.py                # 使用默认（较大）预算
```

本地驱动脚本调用的是同一批阶段函数，只是把云端卷换成本地目录；
附件需按原样放在 `附件/` 下。论文排版阶段（paper/qa/package/release）需要 TeX Live 与中文字体，
不在本地默认序列中。

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
